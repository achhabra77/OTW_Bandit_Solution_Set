!#/bin/bash

##########################################################
#Author: Amar Chhabra
#Purpose: Login Script for Bandit - Over the Wire
#Date: 18 July 2023
##########################################################

echo "****************************************************"
echo "Initiating Over the Wire - Bandit login"
echo "Host Name / IP Address: bandit.labs.overthewire.org"
echo "Port: 2220"
echo "****************************************************"

echo "----------------------------------------------------------------------------"
echo "Please enter the level (i.e. 1) to login"
echo "level must be an integer between 0 to 33"
echo "Upon entering the level number the script will append it to the string bandit."
echo "In example, entering a level of 1 will create a username of bandit1" 
echo "----------------------------------------------------------------------------"

read LEVEL

ssh bandit$LEVEL@bandit.labs.overthewire.org -p 2220
